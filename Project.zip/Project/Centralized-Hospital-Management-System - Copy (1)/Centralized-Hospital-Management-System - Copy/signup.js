document.getElementById("signupForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission

    // Get input values
    var fullname = document.getElementById("fullname").value;
    var email = document.getElementById("email").value;
    var dob = document.getElementById("dob").value;
    var age = document.getElementById("age").value;
    var gender = document.getElementById("gender").value;
    var address = document.getElementById("address").value;
    var phone = document.getElementById("phone").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;

    // Here, you can add your sign-up logic with the provided details
    // For demonstration purposes, let's just log the values
    console.log("Full Name:", fullname);
    console.log("Email:", email);
    console.log("Date of Birth:", dob);
    console.log("Age:", age);
    console.log("Gender:", gender);
    console.log("Address:", address);
    console.log("Phone Number:", phone);
    console.log("Password:", password);
    console.log("Confirm Password:", confirmPassword);

    // You can redirect the user to another page after successful sign-up
    // window.location.href = "login.html";
});
